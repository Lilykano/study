package kano_Kiosk;

public class Main {

	public static void main(String[] args) {
		Kiosk k = new Kiosk();
		k.run();
	}
}



//ArrayList<클래스명> 변수명 = new ArrayList<클래스명>();
//
//해당 클래스내의 객체만 사용가능
//변수명.add(객체)=추가하기
//변수명.get(객체)=불러오기
//변수명.clear=전부 지우고 값을0으로
//변수명.size=
//변수명.remove(숫자)=숫자에 해당하는값을 지우고 전체갯수도 줄어듬
